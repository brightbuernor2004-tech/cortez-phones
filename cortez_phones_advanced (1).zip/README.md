# Cortez Phones Advanced Storefront

A responsive starter website for a Ghanaian dealer selling phones, PlayStation consoles, laptops and accessories.

## Run locally
1. Extract `cortez_phones_advanced.zip`.
2. Open `index.html` in a modern browser.
3. Use **Admin Dashboard** to add/edit products, set stock, upload small product images, view orders, update order statuses, and export a JSON backup.

## Included
- Responsive storefront, search and category filters
- Shopping cart and checkout form
- WhatsApp order handoff to the shop number currently configured as `233530032371`
- Demo product administration and image upload
- Browser-local demo order storage and stock updates
- Exportable JSON backup

## Important demo limitations
This is a front-end prototype. Data is stored in the current browser's `localStorage`; it does not sync across devices or browsers. The admin dashboard has no secure login. Do not deploy this version as a live multi-user shop or store real customer data in it. The sample prices and stock are illustrative and should be replaced with verified stock and prices. Product photo upload is limited to 900 KB per image in the demo.

## Production checklist
Before launch, implement:
- Backend API and database for products, stock, customers and orders
- Secure admin authentication, role checks, input validation and audit logging
- Server-side order creation and inventory reservation to prevent overselling
- Image storage/CDN and file validation
- HTTPS, privacy notice, backups, error monitoring and rate limiting
- Real payment integration and webhook verification

## Ghana Mobile Money integration
You can integrate a provider such as Paystack or Hubtel, subject to merchant approval and provider availability for the intended payment flow.

Recommended production flow:
1. Frontend submits cart and customer details to your backend.
2. Backend validates product IDs, prices and stock from the database; never trust totals sent by the browser.
3. Backend creates a pending order and initiates payment through the provider using server-side secret credentials.
4. Customer completes the provider's checkout or Mobile Money authorization flow.
5. Provider sends a webhook to the backend; backend verifies its signature and/or checks the transaction status directly with the provider.
6. Only after verified success should the backend mark the order paid and finalize inventory.

Never embed secret API keys in `index.html` or `app.js`. Use environment variables on the server. This ZIP intentionally does not pretend to process live payments and contains no API keys.

## Contact details to verify
- Shop: Cortez Phones
- Phone / WhatsApp: 053 003 2371 (configured in demo as `233530032371`)
- Email: chuckybright4@gmail.com

Confirm these contact details before publishing.
